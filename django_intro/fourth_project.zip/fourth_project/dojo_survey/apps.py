from django.apps import AppConfig


class DojoSurveyConfig(AppConfig):
    name = 'dojo_survey'
